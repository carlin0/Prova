/*
# Copyright (C) 2009 Helmuth Saatkamp (helmuthdu)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "variables.h"
#include "themes.h"
#include "translations.h"
#include "help.h"
#include "options.h"
#include "conkycover.h"
#include "conkyforecast.h"
#include "conkyplayer.h"
#include "coverposition.h"
#include "photoposition.h"
#include "conkyrc_cairo.h"
#include "conkyrc_default.h"

//Create and write .conkyrc
void create_conkyrc () {

	if (cairo_set == True)
		conkyrc_cairo();
	else
		conkyrc_default();

}

int main(int argc, char *argv[]) {

	options (argc, argv);

	translation();

	themes();

	coverposition();
	photoposition();

	conkycover();
	conkyforecast();
	conkyplayer();

	create_conkyrc();

	printf("Congratulations, your conkyrc was createad\n");

	return 0;
}
