int 	shiki=0, shikidust=0, dust=0, radiance=0, ambiance=0, elementary=0, custom=0,
		dark=0, alldark=0, alllight=0;

char 	theme[31],
		defaultcolor[31],
		color0[31],
		color1[31],
		color2[31],
		color3[31];

//Themes
void themes () {
	if(strcmp("gnome-brave",theme) == 0) {
		strcpy(color1, "3465A4");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "204A87 3465A4");
	}
	else
		if(strcmp("gnome-dust",theme) == 0) {
			strcpy(color1, "906E4C");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "745536 906E4C");
		}
	else
		if(strcmp("gnome-illustrious",theme) == 0) {
			strcpy(color1, "dc6472");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "C6464B DC6472");
		}
	else
		if(strcmp("gnome-noble",theme) == 0) {
			strcpy(color1, "77507b");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "5C3566 77507B");
		}
	else
		if(strcmp("gnome-wine",theme) == 0) {
			strcpy(color1, "C22F2F");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "A40000 C22F2F");
		}
	else
		if(strcmp("gnome-wise",theme) == 0) {
			strcpy(color1, "709937");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "51751E 709937");
		}
	else
		if(strcmp("gnome-carbonite",theme) == 0) {
			strcpy(color1, "555753");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "2E3436 555753");
		}
	else
		if(strcmp("gnome-tribute",theme) == 0) {
			strcpy(color1, "9C9E8A");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "7D7E60 9C9E8A");
		}
	else
		if(strcmp("ambiance",theme) == 0) {
			strcpy(color0, "292927");
			strcpy(color1, "C6B9A6");
			strcpy(color2, "292927");
			strcpy(color3, "C6B9A6 C6B9A6");
		}
	else
		if(strcmp("radiance",theme) == 0) {
			strcpy(color0, "F0EBE2");
			strcpy(color1, "F56F6E");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "CD646B F56F6E");
		}
	else
		if(strcmp("elementary",theme) == 0) {
			strcpy(color0, "FFFFFF");
			strcpy(color1, "7296BB");
			strcpy(color2, "FFFFFF");
			strcpy(color3, "7296BB 7296BB");
		}
	else
		if(strcmp("shiki-brave",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "3465A4");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "204A87 3465A4");
		}
	else
		if(strcmp("shiki-dust",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "906E4C");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "745536 906E4C");
		}
	else
		if(strcmp("shiki-human",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "E07A1F");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "CE5C00 E07A1F");
		}
	else
		if(strcmp("shiki-illustrious",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "dc6472");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "C6464B DC6472");
		}
	else
		if(strcmp("shiki-noble",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "77507b");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "5C3566 77507B");
		}
	else
		if(strcmp("shiki-wine",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "C22F2F");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "A40000 C22F2F");
		}
	else
		if(strcmp("shiki-wise",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "709937");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "51751E 709937");
		}
	else
		if(strcmp("dust",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "AD946F");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "977951 AD946F");
		}
	else
		if(custom == True)
			strcpy(color3, color1);
	else {
		strcpy(color1, "E07A1F");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "CE5C00 E07A1F");
	}
}

