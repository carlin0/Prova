int 	i, True=1, False=0;

int		cpu=1, cputemp=0, cputype=0,
		aptget=0,
		proc=0, set_process=0,
		swap=0,
		set_battery=0,
		nodata=0, clocktype=0, set_calendar=0, m=0, clock_12h=0,
		nvidia=0,
		set_hd=0, hdtype=0, hdtemp1=0, hdtemp2=0, hdtemp3=0, hdtemp4=0,
		mpd=0, rhythmbox=0, banshee=0, exaile=0, cover=0, covergloobus=0,
		set_photo=0,
		pidgin=0, limit=5, gmail=0,
		todo=0,
		bbcweather=0, bbccode=3849, set_weather=0, weatherplus=0, unit=0,
		set_network=0, eth=0, wlan=0, ppp=0,
		logo=0,
		go2=32, yp=0, yc=0;

char 	player[31],
		side[31],
		weather_code[31], imperial[31],
		logo_letter[31],
		user[31], password[31],
		dev1[31], dev2[31], dev3[31], dev4[31];

int		cairo_set=0, shape=0;
