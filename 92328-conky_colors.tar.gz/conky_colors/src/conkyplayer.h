//Create and write conkyPlayer.template
void conkyplayer () {

	FILE *fp;

	fp = fopen("conkyPlayer.template", "w");

	void trackinfo () {
			if (banshee == True)
			fprintf(fp,"${if_running banshee-1}\n");
			else
				if (rhythmbox == True)
				fprintf(fp,"${if_running rhythmbox}\n");
			else
				fprintf(fp,"${if_running exaile}\n");
			fprintf(fp,"${voffset -22}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", go2, status);
			fprintf(fp,"${goto 100}${voffset 4}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=PT]/[--datatype=LE]${color}${voffset -8}\n");
			fprintf(fp,"$else\n");
			fprintf(fp,"${voffset -22}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto 32}Status:${alignr}${color2}off${color}\n");
			fprintf(fp,"${goto 105}${voffset 24}${execi 10 ~/.conkycolors/bin/conkyCover}${font Droid Sans:style=Bold:size=8}${color2}%s${color}${font}${voffset 8}\n", player);
			fprintf(fp,"$endif");
	}

	void trackinfo_cairo(int alignr, int type){
			if (banshee == True)
			fprintf(fp,"${if_running banshee-1}\n");
			else
				if (rhythmbox == True)
				fprintf(fp,"${if_running rhythmbox}\n");
			else
				fprintf(fp,"${if_running exaile}\n");
			fprintf(fp,"${voffset -1}\n");
			fprintf(fp,"${alignr %d}${color2}${execp ~/.conkycolors/bin/conky%s --datatype=AR | fold -w 18 | sed '1!d'}${color}\n", alignr, player);
			fprintf(fp,"${alignr %d}${color2}${execp ~/.conkycolors/bin/conky%s --datatype=AL | fold -w 18 | sed '1!d'}${color}\n", alignr, player);
			fprintf(fp,"${alignr %d}${color2}${execp ~/.conkycolors/bin/conky%s --datatype=TI | fold -w 18 | sed '1!d'}${color}$else\n", alignr, player);
			fprintf(fp,"${voffset 12}\n");
			if (type == 1)
				fprintf(fp,"${alignr 66}");
			else
				fprintf(fp,"${goto 100}");
			fprintf(fp,"${font Droid Sans:style=Bold:size=8}${color2}%s${color}${font}\n", player);
			fprintf(fp,"$endif\n");
	}

	//lua Theme
	if (cover == 9) {
		trackinfo_cairo(35, 2);
	}
	//cairo Theme
	else
		if (cover == 8) {
		trackinfo_cairo(64, 1);
	}
	//oldvinyl Theme
	else
	if (cover == 7) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 79x58 -p 20,%d}\n", yc);
			trackinfo();
	}
	//glassy Theme
	else
		if (cover == 6) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 68x60 -p 24,%d}\n", yc);
			trackinfo();
		}
	//case Theme
	else
		if (cover == 5) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 68x55 -p 24,%d}\n", yc);
			trackinfo();
		}
	//cd Theme
	else
		if (cover == 4) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 63x55 -p 24,%d}\n", yc);
			trackinfo();
		}
	else
	//vinyl Theme
		if (cover == 3) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 88x62 -p 16,%d}\n", yc);
			trackinfo();
		}
	//simple Theme
	else
		if (cover == 2) {
			if (banshee == True)
			fprintf(fp,"${if_running banshee-1}\n");
			else
				if (rhythmbox == True)
				fprintf(fp,"${if_running rhythmbox}\n");
			else
				fprintf(fp,"${if_running exaile}\n");
			fprintf(fp,"${voffset -12}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", go2, status);
			fprintf(fp,"${voffset 4}${goto %d}${color2}[--datatype=AR]${color}\n", go2);
			fprintf(fp,"${color2}${goto %d}[--datatype=AL]${color}\n", go2);
			fprintf(fp,"${color2}${goto %d}[--datatype=TI]${color}\n", go2);
			fprintf(fp,"${voffset 4}${goto %d}${color2}[--datatype=PT]/[--datatype=LE]${color}", go2);
			fprintf(fp,"${alignr}${color2}${execbar ~/.conkycolors/bin/conky%s --datatype=PP}${color}", player);
			fprintf(fp,"$else\n");
			fprintf(fp,"${voffset -12}${color0}${font Webdings:size=16}U${font}${color}${voffset -2}${goto 32}Status:${alignr}${color2}off${color}\n");
			fprintf(fp,"${voffset 12}$alignc${font Droid Sans:style=Bold:size=8}${color2}%s${color}${font}${voffset -10}\n", player);
			fprintf(fp,"$endif");
		}
		//default Theme
		else {
			if (banshee == True)
			fprintf(fp,"${if_running banshee-1}\n");
			else
				if (rhythmbox == True)
				fprintf(fp,"${if_running rhythmbox}\n");
			else
				fprintf(fp,"${if_running exaile}\n");
			fprintf(fp,"${voffset -12}${color0}${font Webdings:size=16}U${font}${color}${voffset -2}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", go2, status);
			fprintf(fp,"${voffset 4}${color0}${color0}${font Musicelements:size=19}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=AR]${color}\n", go2, song);
			fprintf(fp,"${color2}${alignr}[--datatype=AL]${color}\n");
			fprintf(fp,"${color2}${alignr}[--datatype=TI]${color}\n");
			fprintf(fp,"${voffset -7}${color0}${font Martin Vogel's Symbols:size=19}U${font}${color}${voffset -4}${goto %d}%s:${alignr}${color2}[--datatype=PT]/[--datatype=LE]${color}${voffset 2}", go2, time);
			fprintf(fp,"$else\n");
			fprintf(fp,"${voffset -12}${color0}${font Webdings:size=16}U${font}${color}${voffset -2}${goto 32}Status:${alignr}${color2}off${color}\n");
			fprintf(fp,"${voffset 12}$alignc${font Droid Sans:style=Bold:size=8}${color2}%s${color}${font}${voffset -10}\n", player);
			fprintf(fp,"$endif");
		}
	fclose(fp);
}
