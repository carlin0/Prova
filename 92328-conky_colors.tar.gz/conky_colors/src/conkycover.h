//Create and write conkyCover
void conkycover () {

	FILE *fp;

	fp = fopen("conkyCover", "w");
	
	void cover_size (int size) {
		fprintf(fp,"\tcp \"$player\" $cover\n");
		fprintf(fp,"\tif [ $picture_aspect -gt \"0\" ]; then\n");
		fprintf(fp,"\t\tconvert $cover -thumbnail %dx%d $cover\n", size*2, size);
		fprintf(fp,"\t\tconvert $cover -crop %dx%d+$v_aligh+0  +repage $cover\n", size, size);
		fprintf(fp,"\telse\n");
		fprintf(fp,"\t\tconvert $cover -thumbnail %dx%d $cover\n", size, size*2);
		fprintf(fp,"\t\tconvert $cover -crop %dx%d+0+$v_aligh  +repage $cover\n", size, size);
		fprintf(fp,"\tfi\n");
	}
	
	fprintf(fp,"#!/bin/bash\n");
	fprintf(fp,"#\n");
	fprintf(fp,"# Album art with cd theme in conky\n");
	fprintf(fp,"# by helmuthdu\n\n");
	if (banshee == True) {
		fprintf(fp,"player=\"`~/.conkycolors/bin/conkyBanshee --datatype=CA | sed -e 's/\\\\\\//g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/banshee.png\n");
	}
	else if (rhythmbox == True) {
		fprintf(fp,"album=\"`~/.conkycolors/bin/conkyRhythmbox -d AL`\"\n");
		fprintf(fp,"player=\"`find ~/.cache/rhythmbox/covers/ -name '*'\"$album\"'*'`\"\n");
		fprintf(fp,"#player=\"`~/.conkycolors/bin/conkyRhythmbox -d CA | sed -e 's/\\%%20/\\\\ /g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/rhythmbox.png\n");
	}
	else {
		fprintf(fp,"player=\"`~/.conkycolors/bin/conkyExaile --datatype=CA | sed -e 's/\\\\\\//g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/exaile.png\n");
	}
	fprintf(fp,"cover=/tmp/conkyCover.png\n");
	fprintf(fp,"\n");
	fprintf(fp,"width=`identify -format %%w $photo`\n");
	fprintf(fp,"height=`identify -format %%h $photo`\n");
	fprintf(fp,"picture_aspect=`echo $width - $height | bc`\n");
	fprintf(fp,"v_aligh=`echo $height / \"$height / 5\" | bc`\n");
	fprintf(fp,"\n");
	fprintf(fp,"if [ ! -f \"$player\" ]; then\n");
	if (cover == 4) {
		fprintf(fp,"\t#cp $icon $cover\n");
		fprintf(fp,"\tconvert ~/.conkycolors/icons/CD/base.png ~/.conkycolors/icons/CD/top.png -geometry +0+0 -composite $cover\n");
	}
	else
		if (cover == 5) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Case/base.png ~/.conkycolors/icons/Case/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 6) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Glassy/base.png ~/.conkycolors/icons/Glassy/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 7) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/oldVinyl/base.png ~/.conkycolors/icons/oldVinyl/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		fprintf(fp,"\tconvert ~/.conkycolors/icons/Vinyl/base.png $icon -geometry +36+18 -composite $cover\n");
	fprintf(fp,"else\n");
	if (cover == 4) {
		cover_size(98);
		fprintf(fp,"\tconvert ~/.conkycolors/icons/CD/base.png $cover -geometry +21+5 -composite ~/.conkycolors/icons/CD/top.png -geometry +0+0 -composite $cover\n");
	}
	else
		if (cover == 5) {
		cover_size(99);
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Case/base.png $cover -geometry +8+1 -composite ~/.conkycolors/icons/Case/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 6) {
		cover_size(92);
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Glassy/base.png $cover -geometry +24+8 -composite ~/.conkycolors/icons/Glassy/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 7) {
		cover_size(86);
		fprintf(fp,"\tconvert ~/.conkycolors/icons/oldVinyl/base.png $cover -geometry +4+3 -composite ~/.conkycolors/icons/oldVinyl/top.png -geometry +0+0 -composite $cover\n");
		}
	else {
		cover_size(112);
		fprintf(fp,"\tconvert ~/.conkycolors/icons/Vinyl/base.png $cover -geometry +32+6 -composite ~/.conkycolors/icons/Vinyl/top.png -geometry +0+0 -composite $cover\n");
	}
	fprintf(fp,"fi\n");
	fprintf(fp,"\n");
	fprintf(fp,"exit 0\n");

	fclose(fp);
}
