//Options
void options (int argc, char *argv[]) {

	char *arg;
	char *key, *value;

	strcpy(imperial,"");
	strcpy(user,"<user>");
	strcpy(password,"<password>");
	strcpy(weather_code,"BRXX0043");

	strcpy(defaultcolor, "212526");
	strcpy(color0, "E6E6E6");
	strcpy(color1, "E07A1F");
	strcpy(color2, "E6E6E6");
	strcpy(color3, "CE5C00 E07A1F");

	while (argc--) {

		arg = *argv++;
		key = strsep(&arg, "=");
		value = strsep(&arg, "=");

		if(strcmp("--theme", key) == 0) {
			if(strcmp("gnome-brave", value) == 0 || strcmp("gnome-carbonite", value) == 0 || strcmp("gnome-dust", value) == 0 || strcmp("gnome-human", value) == 0 || strcmp("gnome-illustrious", value) == 0 || strcmp("gnome-noble", value) == 0 || strcmp("gnome-tribute", value) == 0 || strcmp("gnome-wine", value) == 0 || strcmp("gnome-wise", value) == 0)
				strcpy(theme,value);
			else
				if(strcmp("shiki-brave", value) == 0 || strcmp("shiki-human", value) == 0 || strcmp("shiki-illustrious", value) == 0 || strcmp("shiki-noble", value) == 0 || strcmp("shiki-wine", value) == 0 || strcmp("shiki-wise", value) == 0) {
					strcpy(theme,value);
					shiki = True;
					go2 = 38;
				}
			else
				if (strcmp("shiki-dust", value) == 0) {
					strcpy(theme,value);
					shikidust = True;
					go2 = 38;
				}
			else
				if (strcmp("dust", value) == 0) {
					strcpy(theme,value);
					dust = True;
					go2 = 38;
				}
			else
				if (strcmp("radiance", value) == 0) {
					strcpy(theme,value);
					radiance = True;
				}
			else
				if (strcmp("ambiance", value) == 0) {
					strcpy(theme,value);
					ambiance = True;
				}
			else
				if (strcmp("elementary", value) == 0) {
					strcpy(theme,value);
					elementary = True;
				}
			else
				if (strcmp("custom", value) == 0)
					custom = True;
			else {
				printf("ERRO: THEME unavaliable\n");
				exit(0);
			}
		}
		else
			if(strcmp("--default-color", key) == 0)
				strcpy(defaultcolor, value);
		else
			if(strcmp("--color0", key) == 0)
				strcpy(color0, value);
		else
			if(strcmp("--color1", key) == 0)
				strcpy(color1, value);
		else
			if(strcmp("--color2", key) == 0)
				strcpy(color2, value);
		else
			if(strcmp("--dark", key) == 0)
				dark = True;
		else
			if(strcmp("--alldark", key) == 0)
				alldark = True;
		else
			if(strcmp("--alllight", key) == 0)
				alllight = True;
		else
			if(strcmp("--lang", key) == 0) {
				if(strcmp("portuguese", value) == 0 || strcmp("pt", value) == 0 || strcmp("english", value) == 0 || strcmp("en", value) == 0 || strcmp("deutsch", value) == 0 || strcmp("de", value) == 0 || strcmp("spanish", value) == 0 || strcmp("es", value) == 0 || strcmp("italian", value) == 0 || strcmp("it", value) == 0 || strcmp("polish", value) == 0 || strcmp("pl", value) == 0 || strcmp("it", value) == 0 || strcmp("estonian", value) == 0 || strcmp("et", value) == 0 || strcmp("russian", value) == 0 || strcmp("ru", value) == 0 || strcmp("bulgarian", value) == 0 || strcmp("bg", value) == 0 || strcmp("uk",language) == 0 || strcmp("ukrainian",language) == 0)
					strcpy(language,value);
				else {
					printf("ERRO: LANGUAGE unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--cairo", key) == 0)
				cairo_set = True;
		else
			if(strcmp("--shape", key) == 0)
				shape = True;
		else
			if(strcmp("--side", key) == 0)
				strcpy(side,value);
		else
			if(strcmp("--cpu", key) == 0)
				cpu = atoi(value);
		else
			if(strcmp("--orcpu", key) == 0)
				cputype = True;
		else
			if(strcmp("--cputemp", key) == 0)
				cputemp = True;
		else
			if(strcmp("--updates", key) == 0)
				aptget = True;
		else
			if(strcmp("--swap", key) == 0)
				swap = True;
		else
			if(strcmp("--proc", key) == 0){
					proc = atoi(value);
					set_process = True;
			}
		else
			if(strcmp("--nvidia", key) == 0)
				nvidia = True;
		else
			if(strcmp("--clock", key) == 0) {
				if(strcmp("default", value) == 0);
				else
					if (strcmp("classic", value) == 0)
						clocktype = 1;
				else
					if(strcmp("slim", value) == 0)
						clocktype = 2;
				else
					if(strcmp("modern", value) == 0)
						clocktype = 3;
				else
					if(strcmp("lucky", value) == 0)
						clocktype = 4;
				else
					if(strcmp("digital", value) == 0)
						clocktype = 5;
				else
					if(strcmp("off", value) == 0)
						clocktype = 6;
				else
					if(strcmp("cairo", value) == 0)
						clocktype = 7;
				else
					if(strcmp("bigcairo", value) == 0)
						clocktype = 8;
				else {
					printf("ERRO: CLOCK option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--nodata", key) == 0)
					nodata = True;
		else
			if(strcmp("--calendar", key) == 0)
					set_calendar = True;
		else
			if(strcmp("-m", key) == 0)
				m = True;
		else
			if(strcmp("--photo", key) == 0)
				set_photo = 1;
		else
			if(strcmp("--photord", key) == 0)
				set_photo = 2;
		else
			if(strcmp("--todo", key) == 0)
				todo = True;
		else
			if(strcmp("--battery", key) == 0)
				set_battery = True;
		else
			if(strcmp("--hd", key) == 0) {
				if(strcmp("default", value) == 0)
					hdtype = 1;
				else
					if(strcmp("meerkat", value) == 0)
						hdtype = 2;
				else
					if(strcmp("mix", value) == 0)
						hdtype = 3;
				else
					if(strcmp("simple", value) == 0)
						hdtype = 4;
				else {
					printf("ERRO: HD option unavaliable\n");
					exit(0);
				}
				set_hd = True;
			}
		else
			if(strcmp("--hdtemp1", key) == 0) {
				strcpy(dev1,value);
				hdtemp1 = True;
			}
		else
			if(strcmp("--hdtemp2", key) == 0) {
				strcpy(dev2,value);
				hdtemp2 = True;
			}
		else
			if(strcmp("--hdtemp3", key) == 0) {
				strcpy(dev3,value);
				hdtemp3 = True;
			}
		else
			if(strcmp("--hdtemp4", key) == 0) {
				strcpy(dev4,value);
				hdtemp4 = True;
			}
		else
			if(strcmp("--mpd", key) == 0)
				mpd = True;
		else
			if(strcmp("--covergloobus", key) == 0)
				covergloobus = True;
		else
			if(strcmp("--rhythmbox", key) == 0) {
				strcpy(player,"Rhythmbox");
				rhythmbox = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else
					if(strcmp("cairo", value) == 0)
						cover = 8;
				else
					if(strcmp("lua", value) == 0)
						cover = 9;
				else {
					printf("ERRO: RHYTHMBOX option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--exaile", key) == 0) {
				strcpy(player,"Exaile");
				exaile = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else
					if(strcmp("cairo", value) == 0)
						cover = 8;
				else
					if(strcmp("lua", value) == 0)
						cover = 9;
				else {
					printf("ERRO: EXAILE option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--banshee", key) == 0) {
				strcpy(player,"Banshee");
				banshee = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else
					if(strcmp("cairo", value) == 0)
						cover = 8;
				else
					if(strcmp("lua", value) == 0)
						cover = 9;
				else {
					printf("ERRO: BANSHEE option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--pidgin", key) == 0)
				pidgin = True;
		else
			if(strcmp("--limit", key) == 0)
				limit = atoi(value);
		else
			if(strcmp("--gmail", key) == 0)
				gmail = True;
		else
			if(strcmp("--user", key) == 0)
				strcpy(user,value);
		else
			if(strcmp("--passwd", key) == 0)
				strcpy(password,value);
		else
			if(strcmp("--network", key) == 0)
				set_network = True;
		else
			if(strcmp("--eth", key) == 0)
				eth = atoi(value);
		else
			if(strcmp("--wlan", key) == 0)
				wlan = atoi(value);
		else
			if(strcmp("--ppp", key) == 0)
				ppp = atoi(value);
		else
			if(strcmp("--bbcweather", key) == 0) {
				bbccode = atoi(value);
				bbcweather = True;
		}
		else
			if(strcmp("--weather", key) == 0) {
					strcpy(weather_code,value);
					set_weather = True;
			}
		else
			if(strcmp("--simpleweather", key) == 0) {
					strcpy(weather_code,value);
					set_weather = 2;
			}
		else
			if(strcmp("--weatherplus", key) == 0)
				weatherplus = True;
		else
			if(strcmp("--unit", key) == 0) {
				if(strcmp("F", value) == 0) {
					strcpy(imperial," -i");
					unit = True;
				}
				else
					if(strcmp("C", value) == 0);
				else {
					printf("ERRO: UNIT unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--ubuntu", key) == 0) {
				strcpy(logo_letter,"u");
				logo = True;
			}
		else
			if(strcmp("--fedora", key) == 0) {
				strcpy(logo_letter,"N");
				logo = True;
			}
		else
			if(strcmp("--arch", key) == 0) {
				strcpy(logo_letter,"B");
				logo = True;
			}
		else
			if(strcmp("--opensuse", key) == 0) {
				strcpy(logo_letter,"h");
				logo = True;
			}
		else
			if(strcmp("--pardus", key) == 0) {
				strcpy(logo_letter,"i");
				logo = True;
			}
		else
			if(strcmp("--debian", key) == 0) {
				strcpy(logo_letter,"J");
				logo = True;
			}
		else
			if(strcmp("--gentoo", key) == 0) {
				strcpy(logo_letter,"Q");
				logo = True;
			}
		else
			if(strcmp("--xfce", key) == 0) {
				strcpy(logo_letter,"y");
				logo = True;
			}
		else
			if(strcmp("--gnome", key) == 0) {
				strcpy(logo_letter,"T");
				logo = True;
			}
		else
			if(strcmp("-h", key) == 0 || strcmp("--help", key) == 0)
				help();
	}
}
