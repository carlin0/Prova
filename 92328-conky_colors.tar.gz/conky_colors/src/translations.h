char 	sys[31],
		processes[31],
		battery[31],
		uptime[31],
		packages[31],
		date[31],
		photo[31],
		hd[31],
		temperature[31],
		network[31],
		total[31],
		up[31],
		down[31],
		upload[31],
		download[31],
		signal[31],
		localip[31],
		publicip[31],
		nonet[31],
		Weather[31],
		noweather[31],
		station[31],
		rain[31],
		humidity[31],
		sunrise[31],
		sunset[31],
		moon[31],
		updates[31],
		nouve[31],
		status[31],
		song[31],
		time[31],
		nopidgin[31],
		norhythmbox[31];

char 	language[31];

//Languages
void translation () {
	if(strcmp("pt",language) == 0 || strcmp("portuguese",language) == 0){
		strcpy(sys,"SISTEMA");
		strcpy(battery,"Bateria");
		strcpy(uptime,"Atividade");
		strcpy(processes,"Processos");
		strcpy(packages,"Pacotes");
		strcpy(date,"DATA");
		strcpy(photo,"FOTO");
		strcpy(hd,"HD");
		strcpy(temperature,"Temperatura");
		strcpy(updates,"Atualizações");
		strcpy(nouve,"(s)");
		strcpy(network,"REDE");
		strcpy(up,"Up");
		strcpy(down,"Down");
		strcpy(upload,"Upload");
		strcpy(download,"Download");
		strcpy(signal,"Sinal");
		strcpy(total,"Total");
		strcpy(localip,"Ip local");
		strcpy(publicip,"Ip externo");
		strcpy(nonet,"Rede indisponível");
		strcpy(Weather,"TEMPO");
		strcpy(noweather,"Tempo indisponível");
		strcpy(station,"Estação");
		strcpy(rain,"Chuva");
		strcpy(humidity,"Umidade");
		strcpy(sunrise,"Amanhecer");
		strcpy(sunset,"Anoitecer");
		strcpy(moon,"Lua");
		strcpy(status,"Status");
		strcpy(song,"Música");
		strcpy(time,"Tempo");
		strcpy(nopidgin,"Pidgin não está rodando");
		strcpy(norhythmbox,"Rhythmbox não está rodando");
	}
	else
		if(strcmp("it",language) == 0 || strcmp("italian",language) == 0){
			strcpy(sys,"SISTEMA");
			strcpy(battery,"Batteria");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Processi");
			strcpy(packages,"Pacchetti");
			strcpy(date,"DATA");
			strcpy(photo,"FOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Aggiornamenti");
			strcpy(nouve,"nouve");
			strcpy(network,"RETE");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Segnale");
			strcpy(total,"Totale");
			strcpy(localip,"Ip Locale");
			strcpy(publicip,"Ip Pubblico");
			strcpy(nonet,"Rete Non Disponibile");
			strcpy(Weather,"METEO");
			strcpy(noweather,"Meteo Non Disponibile");
			strcpy(station,"Stazione");
			strcpy(rain,"Pioggia");
			strcpy(humidity,"Umidità");
			strcpy(sunrise,"Alba");
			strcpy(sunset,"Tramonto");
			strcpy(moon,"Luna");
			strcpy(status,"Status");
			strcpy(song,"Canzone");
			strcpy(time,"Tempo");
			strcpy(nopidgin,"Pidgin non è in esecuzione");
			strcpy(norhythmbox,"Rhythmbox non è in esecuzione");
	}
	else
		if(strcmp("es",language) == 0 || strcmp("spanish",language) == 0){
			strcpy(sys,"SISTEMA");
			strcpy(battery,"Batería");
			strcpy(uptime,"Actividad");
			strcpy(processes,"Procesos");
			strcpy(packages,"Paquetes");
			strcpy(date,"FECHA");
			strcpy(photo,"FOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Actualizaciones");
			strcpy(nouve,"Nuevo(s)");
			strcpy(network,"RED");
			strcpy(up,"Envío");
			strcpy(down,"Recibo");
			strcpy(upload,"Enviado");
			strcpy(download,"Recibido");
			strcpy(signal,"Señal");
			strcpy(total,"Total");
			strcpy(localip,"Ip Local");
			strcpy(publicip,"Ip Pública");
			strcpy(nonet,"Red no disponible");
			strcpy(Weather,"CLIMA");
			strcpy(noweather,"Clima no disponible");
			strcpy(station,"Estación");
			strcpy(rain,"Lluvia");
			strcpy(humidity,"Humedad");
			strcpy(sunrise,"Amanecer");
			strcpy(sunset,"Anochecer");
			strcpy(moon,"Luna");
			strcpy(status,"Situación");
			strcpy(song,"Canción");
			strcpy(time,"Tiempo");
			strcpy(nopidgin,"Pidgin no esta corriendo");
			strcpy(norhythmbox,"Rhythmbox no esta corriendo");
		}
	else
		if(strcmp("de",language) == 0 || strcmp("deutsch",language) == 0){
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Batterie");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Prozesse");
			strcpy(packages,"Pakete");
			strcpy(date,"DATUM");
			strcpy(photo,"PHOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatur");
			strcpy(updates,"Updates");
			strcpy(nouve,"nouve");
			strcpy(network,"NETZWERK");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Signal");
			strcpy(total,"Insgesamt");
			strcpy(localip,"Lokale IP");
			strcpy(publicip,"Öffentliche IP");
			strcpy(nonet,"Netzwerk nicht verfügbar");
			strcpy(Weather,"WETTER");
			strcpy(noweather,"Wetter nicht verfügbar");
			strcpy(station,"Station");
			strcpy(rain,"Regen");
			strcpy(humidity,"Feuchte");
			strcpy(sunrise,"Sonnenaufgang");
			strcpy(sunset,"Sonnenuntergang");
			strcpy(moon,"Mond");
			strcpy(status,"Status");
			strcpy(song,"Gesang");
			strcpy(time,"Zeit");
			strcpy(nopidgin,"Pidgin nicht läuft");
			strcpy(norhythmbox,"Rhythmbox nicht läuft");
		}
	else
		if(strcmp("pl",language) == 0 || strcmp("polish",language) == 0) {
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Bateria");
			strcpy(uptime,"Uruchomiony");
			strcpy(processes,"Procesów");
			strcpy(packages,"Pakiety");
			strcpy(date,"DATA");
			strcpy(photo,"ZDJĘCIE");
			strcpy(hd,"DYSKI");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Aktualizacje");
			strcpy(nouve,"Nowe");
			strcpy(network,"SIEĆ");
			strcpy(up,"Wys.");
			strcpy(down,"Pob.");
			strcpy(upload,"Wysłano");
			strcpy(download,"Pobrano");
			strcpy(signal,"Sygnał");
			strcpy(total,"Oddanych");
			strcpy(localip,"Lokalne IP");
			strcpy(publicip,"Publiczne IP");
			strcpy(nonet,"Sieć Niedostępna");
			strcpy(Weather,"POGODA");
			strcpy(noweather,"Pogoda niedostępna");
			strcpy(station,"Dworzec");
			strcpy(rain,"Deszcz");
			strcpy(humidity,"Wilgotność");
			strcpy(sunrise,"Świt");
			strcpy(sunset,"Zachód słońca");
			strcpy(moon,"Księżyc");
			strcpy(status,"Stan");
			strcpy(song,"Utwór");
			strcpy(time,"Pozycja");
			strcpy(nopidgin,"Pidgin nie działa");
			strcpy(norhythmbox,"Rhythmbox nie działa");
		}
	else
		if(strcmp("et",language) == 0 || strcmp("estonian",language) == 0){
			strcpy(sys,"SÜSTEEM");
			strcpy(battery,"Aku");
			strcpy(uptime,"Tööaeg");
			strcpy(processes,"Protsessid");
			strcpy(packages,"Pakendid");
			strcpy(date,"KUUPÄEV");
			strcpy(photo,"FOTO");
			strcpy(hd,"KÕVAKETAS");
			strcpy(temperature,"Temperatuur");
			strcpy(updates,"Uuendused");
			strcpy(nouve,"uut");
			strcpy(network,"VÕRK");
			strcpy(up,"Üles");
			strcpy(down,"Alla");
			strcpy(upload,"Üleslaetud");
			strcpy(download,"Allalaetud");
			strcpy(signal,"Signaal");
			strcpy(total,"Kokku");
			strcpy(localip,"Kohalik IP");
			strcpy(publicip,"Avalik IP");
			strcpy(nonet,"Võrk pole saadaval");
			strcpy(Weather,"ILM");
			strcpy(noweather,"Ilm pole saadaval");
			strcpy(station,"Jaam");
			strcpy(rain,"Vihm");
			strcpy(humidity,"Niiskus");
			strcpy(sunrise,"Päikesetõus");
			strcpy(sunset,"Päikeseloojangu");
			strcpy(moon,"Kuu");
			strcpy(status,"Staatus");
			strcpy(song,"Laul");
			strcpy(time,"Aeg");
			strcpy(nopidgin,"Pidgin ei tööta");
			strcpy(norhythmbox,"Rhythmbox ei tööta");
		}
	else
		if(strcmp("ru",language) == 0 || strcmp("russian",language) == 0) {
			strcpy(sys,"СИСТЕМА");
			strcpy(battery,"Батарея");
			strcpy(uptime,"Время работы");
			strcpy(processes,"Процессы");
			strcpy(packages,"Пакеты");
			strcpy(date,"ДАТА");
			strcpy(photo,"ФОТО");
			strcpy(hd,"ДИСКИ");
			strcpy(temperature,"Температура");
			strcpy(updates,"Обновления");
			strcpy(nouve,"Новое");
			strcpy(network,"СЕТЬ");
			strcpy(up,"Отправка");
			strcpy(down,"Приём");
			strcpy(upload,"Всего отправлено");
			strcpy(download,"Всего получено");
			strcpy(signal,"Сигнал");
			strcpy(total,"Всего");
			strcpy(localip,"Локальный IP");
			strcpy(publicip,"Внешний IP");
			strcpy(nonet,"Сеть недоступна");
			strcpy(Weather,"ПОГОДА");
			strcpy(noweather,"Информация о погоде недоступна");
			strcpy(station,"Станция");
			strcpy(rain,"Дождь");
			strcpy(humidity,"Влажность");
			strcpy(sunrise,"Восход");
			strcpy(sunset,"Закат");
			strcpy(moon,"Луна");
			strcpy(status,"Статус");
			strcpy(song,"Композиция");
			strcpy(time,"Время");
			strcpy(nopidgin,"Pidgin не запущен");
			strcpy(norhythmbox,"Rhythmbox не запущен");
		}
	else
		if(strcmp("bg",language) == 0 || strcmp("bulgarian",language) == 0) {
			strcpy(sys,"СИСТЕМА");
			strcpy(battery,"Батерия");
			strcpy(uptime,"Време на работа");
			strcpy(processes,"Процеси");
			strcpy(packages,"пакет(а)");
			strcpy(date,"ДАТА");
			strcpy(photo,"СНИМКА");
			strcpy(hd,"ТВЪРД ДИСК");
			strcpy(temperature,"Температура");
			strcpy(updates,"Актуализации");
			strcpy(nouve,"Нови");
			strcpy(network,"МРЕЖА");
			strcpy(up,"Качване");
			strcpy(down,"Сваляне");
			strcpy(upload,"Качено");
			strcpy(download,"Свалено");
			strcpy(signal,"Сила на сигнала");
			strcpy(total,"Общо");
			strcpy(localip,"Локален IP");
			strcpy(publicip,"Външен IP");
			strcpy(nonet,"Мрежата е недостъпна");
			strcpy(Weather,"ВРЕМЕТО");
			strcpy(noweather,"Няма информация за времето");
			strcpy(station,"станция");
			strcpy(rain,"дъжд");
			strcpy(humidity,"влажност");
			strcpy(sunrise,"изгрев");
			strcpy(sunset,"залез");
			strcpy(moon,"луна");
			strcpy(status,"Статус");
			strcpy(song,"Песен");
			strcpy(time,"Време");
			strcpy(nopidgin,"Pidgin не е стартиран");
			strcpy(norhythmbox,"Rhythmbox не е стартиран");
		}
	else
		if(strcmp("uk",language) == 0 || strcmp("ukrainian",language) == 0) {
			strcpy(sys,"СИСТЕМА");
			strcpy(battery,"Батарея");
			strcpy(uptime,"Час роботи");
			strcpy(processes,"Процеси");
			strcpy(packages,"Пакунки");
			strcpy(date,"ДАТА");
			strcpy(photo,"ФОТО");
			strcpy(hd,"ДИСКИ");
			strcpy(temperature,"Температура");
			strcpy(updates,"Оновлення");
			strcpy(nouve,"Нове");
			strcpy(network,"МЕРЕЖА");
			strcpy(up,"Відправка");
			strcpy(down,"Прийом");
			strcpy(upload,"Всього відправлено");
			strcpy(download,"Всього отримано");
			strcpy(signal,"Сигнал");
			strcpy(total,"Всього");
			strcpy(localip,"Локальний IP");
			strcpy(publicip,"Зовнішній IP");
			strcpy(nonet,"Мережа недоступна");
			strcpy(Weather,"ПОГОДА");
			strcpy(noweather,"Інформация про погоду недоступна");
			strcpy(station,"Станція");
			strcpy(rain,"Дощ");
			strcpy(humidity,"Вологість");
			strcpy(sunrise,"Схід");
			strcpy(sunset,"Захід");
			strcpy(moon,"Місяць");
			strcpy(status,"Статус");
			strcpy(song,"Композиція");
			strcpy(time,"Час");
			strcpy(nopidgin,"Pidgin не запущений");
			strcpy(norhythmbox,"Rhythmbox не запущений");
		}
		else {
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Battery");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Processes");
			strcpy(packages,"Packages");
			strcpy(date,"DATE");
			strcpy(photo,"PHOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperature");
			strcpy(updates,"Updates");
			strcpy(nouve,"nouve");
			strcpy(network,"NETWORK");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Signal");
			strcpy(total,"Total");
			strcpy(localip,"Local IP");
			strcpy(publicip,"Public IP");
			strcpy(nonet,"Network Unavailable");
			strcpy(Weather,"WEATHER");
			strcpy(noweather,"Weather Unavailable");
			strcpy(station,"Station");
			strcpy(rain,"Rain");
			strcpy(humidity,"Humidity");
			strcpy(sunrise,"Sunrise");
			strcpy(sunset,"Sunset");
			strcpy(moon,"Moon");
			strcpy(status,"Status");
			strcpy(song,"Song");
			strcpy(time,"Time");
			strcpy(nopidgin,"Pidgin not running");
			strcpy(norhythmbox,"Rhythmbox not running");
		}
}
