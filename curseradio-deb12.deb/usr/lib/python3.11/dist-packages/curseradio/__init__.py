__author__ = "Gordon Ball <gordon@chronitis.net>"
__version__ = "0.2"

from .curseradio import OPMLBrowser
